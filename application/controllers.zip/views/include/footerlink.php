<!-- <script data-cfasync="false" src="../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> -->
<script src="<?= base_url() ?>/assets/js/vendor/jquery-3.6.0.min.js"></script>
<script src="<?= base_url() ?>/assets/js/vendor/waypoints.min.js"></script>
<script src="<?= base_url() ?>/assets/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url() ?>/assets/js/meanmenu.js"></script>
<script src="<?= base_url() ?>/assets/js/swiper-bundle.min.js"></script>
<script src="<?= base_url() ?>/assets/js/owl.carousel.min.js"></script>
<script src="<?= base_url() ?>/assets/js/magnific-popup.min.js"></script>
<script src="<?= base_url() ?>/assets/js/parallax.min.js"></script>
<script src="<?= base_url() ?>/assets/js/backToTop.js"></script>
<script src="<?= base_url() ?>/assets/js/jquery-ui-slider-range.js"></script>
<script src="<?= base_url() ?>/assets/js/nice-select.min.js"></script>
<script src="<?= base_url() ?>/assets/js/counterup.min.js"></script>
<script src="<?= base_url() ?>/assets/js/ajax-form.js"></script>
<script src="<?= base_url() ?>/assets/js/wow.min.js"></script>
<script src="<?= base_url() ?>/assets/js/beforeafter.jquery-1.0.0.js"></script>
<script src="<?= base_url() ?>/assets/js/isotope.pkgd.min.js"></script>
<script src="<?= base_url() ?>/assets/js/imagesloaded.pkgd.min.js"></script>
<script src="<?= base_url() ?>/assets/js/main.js"></script>
<script src="<?= base_url() ?>/assets/js/loginscript.js"></script>
<script src="<?= base_url() ?>/assets/ecommerce/cart.js"></script>
<script>
	$('.carousel').carousel({
		interval: 2000
	})

	$('.autoplay').slick({
		slidesToShow: 3,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 2000,
	});
</script>
<script>
	// JavaScript to change the text transform of the title
	var titleElement = document.getElementById("dynamic-title");
	titleElement.innerText = titleElement.innerText.toUpperCase();
</script>
