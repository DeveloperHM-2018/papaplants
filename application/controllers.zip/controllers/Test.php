<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Test extends CI_Controller
{
	public function index()
	{
		// $category = $this->CommonModal->getAllRows('category');
		// foreach ($category as $row) {
		// 	$data = url_title($row['name'], '-', true);
		// 	$savedata = $this->CommonModal->updateRowById('category', 'id', $row['id'], ['meta_url' => $data]);

		// }
		// $pp_product = $this->CommonModal->getAllRows('product');
		// foreach ($pp_product as $row) {
		// 	$datas = url_title($row['name'], '-', true);
		// 	$savedatas = $this->CommonModal->updateRowById('product', 'id', $row['id'], ['meta_url' => $datas]);

		// }
	}
}
