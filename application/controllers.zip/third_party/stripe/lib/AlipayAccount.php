<?php
namespace Stripe;
/**
 * Class AlipayAccount
 *
 * @package Stripe
 */
class AlipayAccount extends ExternalAccount
{
}
